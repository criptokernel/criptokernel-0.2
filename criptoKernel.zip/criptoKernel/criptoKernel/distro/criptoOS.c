#include "../apps/calculator.h"
#include "../apps/text.h"
#include <libkernel/io.h>
void apps(){
    print_string("APPS \n \n what app? \n >");
    char appk = input();
    if(appk == 'c'){
        mini_calc_pi_tau();
    }
    else if(appk == 'e'){
        mini_editor();
    }
    
}

void run(){
    
    fs_create_file("log.txt",8);
    uint8_t dados[] = "init system";
    fs_write_file("log.txt", dados, 0, sizeof(dados));



    print_string("please use \n s - shell \n r - reboot \n e - exit \n a - apps \n f-filesystem\nokay? \n \n ");
    print_string("welcome user from cripto\n>>");
    char com = input();
    print_string(com);
    if(com == 's'){
    nsh();
    }
    else if(com == 'r'){
        asm volatile("int $0x19");
    }
    else if(com == 'e'){
        asm volatile("hlt");
    }
    else if(com == 'a'){
        apps();
    }
    else if(com == 'f'){
        fsh();
    }
    else{
      
        int x = 90;
        while(x > 1){
            asm volatile("nop");
            x--;
        }       
        asm volatile("int $0x19");
    }
}
