#ifndef STRING_H
#define STRING_H

int strlen(const char* s);
char* strcpy(char* dest, const char* src);
void strncpy(char* dest, const char* src, int n);  
int strcmp(const char* s1, const char* s2);
void memcpy(void* dest, const void* src, int n);   
char* strchr(const char* s, char c);
char* strcat(char* dest, const char* src);
#endif
