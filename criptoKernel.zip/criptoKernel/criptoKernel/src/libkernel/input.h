#ifndef A_H
#define A_H
#include <libkernel/io.h>

const char scancode_tab[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=', '\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0, 'a','s','d','f','g','h','j','k','l',';','\'','`',
    0,'\\','z','x','c','v','b','n','m',',','.','/', 0,
    '*', 0,' '
};

char scan();

char input() {
    unsigned char code = scan();
    if (code < 128)
        return scancode_tab[code];
    return 0;
}

void input_string(char *buf, int max) {
    int i = 0;
    while (i < max - 1) {
        char c = input();
        if (c == '\n') {
            print_char('\n');
            break;
        }
        if (c == '\b') {
            if (i > 0) {
                i--;
                print_char('\b');
            }
            continue;
        }
        print_char(c);
        buf[i++] = c;
    }
    buf[i] = 0;
}

#endif

