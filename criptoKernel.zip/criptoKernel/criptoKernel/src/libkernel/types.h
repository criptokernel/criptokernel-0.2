#ifndef TYPES_H
#define TYPES_H

typedef unsigned long size_t;

#endif

