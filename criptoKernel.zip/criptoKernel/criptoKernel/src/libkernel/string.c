#include "string.h"
#include "types.h"

#define NULL ((void*)0)

void *memset(void *dest, int value, size_t count) {
    unsigned char *d = dest;
    while(count--) *d++ = (unsigned char)value;
    return dest;
}

char *strcpy(char *dest, const char *src) {
    char *r = dest;
    while((*dest++ = *src++));
    return r;
}

void memcpy(void* dest, const void* src, int n) {
    char* d = (char*)dest;
    char* s = (char*)src;
    for (int i = 0; i < n; i++) {
        d[i] = s[i];
    }
}

int strcmp(const char* s1, const char* s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(unsigned char*)s1 - *(unsigned char*)s2;
}

void strncpy(char* dest, const char* src, int n) {
    int i;
    for (i = 0; i < n - 1 && src[i]; i++) {
        dest[i] = src[i];
    }
    dest[i] = '\0';
}

int strlen(const char* s) {
    int len = 0;
    while (s[len]) len++;
    return len;
}

#define NULL ((void*)0)

int atoi(const char* s) {
    int result = 0;
    while (*s >= '0' && *s <= '9') {
        result = result * 10 + (*s - '0');
        s++;
    }
    return result;
}

char* strchr(const char* s, char c) {
    while (*s) {
        if (*s == c) return (char*)s;
        s++;
    }
    return NULL;
}

char* strcat(char* dest, const char* src) {
    char* ptr = dest;
    while (*ptr != '\0') ptr++;
    while (*src != '\0') *ptr++ = *src++;
    *ptr = '\0';
    return dest;
}

