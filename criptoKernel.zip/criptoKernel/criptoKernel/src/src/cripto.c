#include "../libkernel/io.h"
#include "../libkernel/string.h"
#define NULL ((void*)0)
#define VGA_MEMORY 0xB8000
#define VGA_COLS   80
#define VGA_ROWS   25
#include <stdint.h>
#include <stddef.h>

#define KHEAP_SIZE (64 * 1024)  // 64 KB, muda se quiser

static uint8_t kernel_heap[KHEAP_SIZE];
static size_t heap_offset = 0;

void* kmalloc(size_t size) {
    // alinhar para 8 bytes
    size = (size + 7) & ~7;

    if (heap_offset + size > KHEAP_SIZE) {
        return NULL; // sem memória, caos corporativo
    }

    void* ptr = &kernel_heap[heap_offset];
    heap_offset += size;

    return ptr;
}

typedef struct task {
    int state;
    int finished;
    void (*run)(struct task* self);
    struct task* next;
} task_t;

task_t* task_list = NULL;
task_t* current = NULL;

void print_char(char c);
void print_string(const char* str);

#define TASK_BEGIN() switch(self->state) { case 0:
#define TASK_YIELD() do { self->state = __LINE__; return; case __LINE__:; } while (0)
#define TASK_END() } self->finished = 1; return;

task_t* create_task(void (*fn)(task_t*)) {
    task_t* t = kmalloc(sizeof(task_t));
    t->state = 0;
    t->finished = 0;
    t->run = fn;

    if (!task_list) {
        task_list = t;
        t->next = t;
    } else {
        t->next = task_list->next;
        task_list->next = t;
    }

    return t;
}
void schedule() {
    if (!current) return;
    current = current->next;

    if (!current->finished) {
        current->run(current);
    }
}

void kernelf(const char* str) {
    print_string("caution::");
    while (*str) {
        print_char(*str++);
    }
}
void kernelp(const char *msg) {
    clear_screen(); // opcional — deixa vibe dark mode apocalíptico

    kernelf("\n\n==============================\n");
    kernelf("        KERNEL  PANIC\n");
    kernelf("==============================\n\n");

    kernelf("The system has encountered a fatal error.\n");
    kernelf("Reason: ");

    while (*msg) print_char(*msg++);

    kernelf("\n\nSystem halted.\n");
    
    // trava completamente
    while(1) {
        asm volatile("hlt");
    }
}

void clear_screen() {
    uint16_t *vga = (uint16_t*)VGA_MEMORY;

    for (int i = 0; i < VGA_COLS * VGA_ROWS; i++) {
        vga[i] = (0x07 << 8) | ' ';   
    }
}
void invert_colors() {
    uint16_t *vga = (uint16_t*)VGA_MEMORY;

    for (int i = 0; i < VGA_COLS * VGA_ROWS; i++) {
        uint8_t ch  = vga[i] & 0xFF;
        uint8_t attr = (vga[i] >> 8);

     
        uint8_t fg = attr & 0x0F;
        uint8_t bg = (attr >> 4) & 0x0F;

     
        uint8_t new_attr = (fg << 4) | bg;

        vga[i] = (new_attr << 8) | ch;
    }
}


#define FS_START_SECTOR 2099
#define FS_MAX_FILES 64
#define FS_FILENAME_LEN 32
#define FS_SECTOR_SIZE 512
#define FS_MAGIC 0x55AA1234


typedef struct {
    char filename[FS_FILENAME_LEN];
    uint32_t start_sector;
    uint32_t size_bytes;
    uint8_t flags; 
} file_entry_t;

typedef struct {
    uint32_t magic;
    uint32_t file_count;
    file_entry_t files[FS_MAX_FILES];
} fs_superblock_t;
long long __divdi3(long long a, long long b) {
    if (b == 0) {
 
        return 0;
    }

    // pega sinais
    int neg = 0;
    if (a < 0) { a = -a; neg ^= 1; }
    if (b < 0) { b = -b; neg ^= 1; }

    // divide sem sinal
    unsigned long long ua = (unsigned long long) a;
    unsigned long long ub = (unsigned long long) b;
    unsigned long long result = 0;

    for (int i = 63; i >= 0; i--) {
        if ((ua >> i) >= ub) {
            ua -= (ub << i);
            result |= (1ULL << i);
        }
    }

    // aplica sinal
    if (neg) return -(long long)result;
    return (long long)result;
}

void print_char(char c) {
    // Imprimir caractere na tela (modo texto VGA)
    volatile char* video_memory = (volatile char*)0xB8000;
    static int cursor_pos = 0;
    
    if (c == '\n') {
        cursor_pos += 80 - (cursor_pos % 80);
    } else {
        video_memory[cursor_pos * 2] = c;
        video_memory[cursor_pos * 2 + 1] = 0x07; // Cor: cinza claro em preto
        cursor_pos++;
    }
    
    // Scroll se necessário
    if (cursor_pos >= 80 * 25) {
        // Implementar scroll básico
        for (int i = 0; i < 80 * 24 * 2; i++) {
            video_memory[i] = video_memory[i + 80 * 2];
        }
        for (int i = 80 * 24 * 2; i < 80 * 25 * 2; i += 2) {
            video_memory[i] = ' ';
            video_memory[i + 1] = 0x07;
        }
        cursor_pos = 80 * 24;
    }
}

void print_string(const char* str) {
    while (*str) {
        print_char(*str++);
    }
}


// Declarações antecipadas (protótipos)
unsigned char inb(unsigned short port);
char scancode_to_ascii(unsigned char scancode);

char get_char_simulated(void) {
    // Verifica se há tecla disponível
    while ((inb(0x64) & 0x01) == 0) {
        // Espera até que uma tecla esteja disponível
        asm volatile("pause");
    }
    
    // Lê o scancode do teclado
    unsigned char scancode = inb(0x60);
    
    // Converte scancode para caractere ASCII
    return scancode_to_ascii(scancode);
}

// Implementação da função inb
unsigned char inb(unsigned short port) {
    unsigned char result;
    asm volatile("inb %1, %0" : "=a"(result) : "Nd"(port));
    return result;
}

// Tabela de conversão básica de scancode para ASCII
char scancode_to_ascii(unsigned char scancode) {
    // Tabela básica - apenas teclas comuns
    static const char scancode_table[128] = {
        0,   0,   '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 
        '-', '=', 0,   0,   'q', 'w', 'e', 'r', 't', 'y', 'u', 'i',
        'o', 'p', '[', ']', '\n', 0,   'a', 's', 'd', 'f', 'g', 'h',
        'j', 'k', 'l', ';', '\'', '`', 0,   '\\', 'z', 'x', 'c', 'v',
        'b', 'n', 'm', ',', '.', '/', 0,   '*', 0,   ' ', 0,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
        0,   0,   0,   0,   0,   0,   0,   0
    };
    
    // Ignora key-up events (bit 7 setado)
    if (scancode & 0x80) {
        return 0;
    }
    
    // Retorna o caractere correspondente
    if (scancode < sizeof(scancode_table)) {
        return scancode_table[scancode];
    }
    
    return 0;
}
void input_stringer(char* buffer, int max_length) {
    int pos = 0;
    char c;
    
    // Mostrar prompt
    print_string("> ");
    
    while (pos < max_length - 1) {
        // Em sistema real, aqui leríamos da porta do teclado
        // Por enquanto, simula entrada com valores fixos
        c = get_char_simulated();
        
        if (c == '\n' || c == '\r') { // Enter
            print_char('\n');
            buffer[pos] = '\0';
            return;
        } else if (c == '\b') { // Backspace
            if (pos > 0) {
                pos--;
                print_char('\b');
                print_char(' ');
                print_char('\b');
            }
        } else if (c >= 32 && c <= 126) { // Caracteres ASCII imprimíveis
            if (pos < max_length - 1) {
                print_char(c);
                buffer[pos] = c;
                pos++;
            }
        }
        // Ignorar outros caracteres especiais
    }
    
    // Garantir que a string termina com null
    buffer[max_length - 1] = '\0';
}

// Função simulada para obter caractere (substituir por leitura real do teclado)

// --- ATA PIO (lê/escreve HD IDE/QEMU) ---

// Espera o disco ficar pronto

// Função principal do kernel
// Função principal do kernel[

#include <libkernel/input.h>
#include <stdint.h>
#include <libkernel/io.h>

#define CMOS_ADDRESS 0x70
#define CMOS_DATA    0x71

#define MAX_HISTORY 10
#define MAX_CMD_LEN 64

char history[MAX_HISTORY][MAX_CMD_LEN];
int hist_count = 0;
int hist_idx = 0;

// ------------------- Funções CMOS / RTC -------------------
uint8_t cmos_read(uint8_t reg) {
    outb(CMOS_ADDRESS, reg);
    return inb(CMOS_DATA);
}

uint8_t bcd_to_bin(uint8_t val) {
    return (val & 0x0F) + ((val / 16) * 10);
}

int get_time_seconds() {
    uint8_t sec = bcd_to_bin(cmos_read(0x00));
    uint8_t min = bcd_to_bin(cmos_read(0x02));
    uint8_t hour = bcd_to_bin(cmos_read(0x04));
    return hour * 3600 + min * 60 + sec;
}

// ------------------- Funções auxiliares -------------------
void itoa(int n, char* str) {
    int i = 0;
    if (n == 0) { str[i++] = '0'; str[i] = 0; return; }
    char buf[10]; int j = 0;
    while(n > 0) { buf[j++] = '0' + (n % 10); n /= 10; }
    while(j > 0) { str[i++] = buf[--j]; }
    str[i] = 0;
}

void add_history(const char* cmd) {
    int i;
    if (hist_count < MAX_HISTORY) { i = hist_count++; }
    else {
        for (i = 1; i < MAX_HISTORY; i++)
            for (int j = 0; j < MAX_CMD_LEN; j++)
                history[i-1][j] = history[i][j];
        i = MAX_HISTORY - 1;
    }
    int j = 0;
    while (cmd[j] && j < MAX_CMD_LEN-1) { history[i][j] = cmd[j]; j++; }
    history[i][j] = 0;
}

void vga_write(char c, char color, int x, int y) {
    volatile char* video = (volatile char*)0xB8000;
    video[(y*80 + x)*2] = c;
    video[(y*80 + x)*2 + 1] = color;
}

// ------------------- Conversão hex -> int -------------------
int hex_to_int(const char* str) {
    int result = 0;
    int i = 0;
    char c;
    while ((c = str[i])) {
        result <<= 4; // shift 4 bits
        if (c >= '0' && c <= '9') result += c - '0';
        else if (c >= 'A' && c <= 'F') result += c - 'A' + 10;
        else if (c >= 'a' && c <= 'f') result += c - 'a' + 10;
        else break;
        i++;
    }
    return result;
}

// ------------------- Funções de memória -------------------
void dump_memory(uint8_t* addr, int len) {
    char buf[12];
    for (int i = 0; i < len; i+=16) {
        itoa((int)(addr+i), buf);
        print_string(buf);
        print_string(": ");
        for (int j = 0; j < 16 && i+j < len; j++) {
            itoa(addr[i+j], buf);
            print_string(buf); print_string(" ");
        }
        print_string("\n");
    }
}

uint8_t mem_read(uint8_t* addr) { return *addr; }
void mem_write(uint8_t* addr, uint8_t val) { *addr = val; }

// ------------------- Funções de tela -------------------
void fill_screen(char c, char color) {
    volatile char* video = (volatile char*)0xB8000;
    for (int i=0;i<80*25;i++) { video[i*2]=c; video[i*2+1]=color; }
}

void xor_screen() {
    volatile char* video = (volatile char*)0xB8000;
    for(int i=1;i<80*25*2;i+=2){video[i]^=0xFF;}
}

void zero_screen() {
    volatile char* video = (volatile char*)0xB8000;
    for (int i=0;i<80*25*2;i++) video[i]=0;
}

// ------------------- Comando principal -------------------
void ish() {
    char buffer[MAX_CMD_LEN];
    while (1) {
        print_string("\n> ");
        int idx = 0;
        while (1) {
            char ch = input();  
            if (ch == '\n' || ch == '\r') { buffer[idx] = 0; break; }
            else if (ch == '\b') { if (idx > 0) idx--; }
            else if (idx < MAX_CMD_LEN - 1) { buffer[idx++] = ch; print_char(ch); }
        }

        add_history(buffer);

        switch(buffer[0]) {
            case 'h': // help
                print_string("\nCommands:\n"
                             " h - help\n c - clear  e - exit\n r - reboot\n"
                             " i - info\n t - time a - invert colors\n"
                             " s - test string p - echo string\n b - history\n"
                             " w - vga write d - dump mem\n m - read mem\n o - write mem\n"
                             " u - uppercase l - lowercase\n f - fill screen\n x - xor screen\n"
                             " v - version g - greet\n n - next history\n q - quit\n y - yield\n"
                             "  z - zero screen \n");
                break;
            case 'c': { volatile char* video_memory=(volatile char*)0xB8000; for(int i=0;i<80*25*2;i+=2){video_memory[i]=' ';video_memory[i+1]=0x07;} break; }
            case 'e':
            case 'q': asm volatile("hlt"); break;
            case 'r': asm volatile("int $0x19"); break;
            case 'i': print_string("\nbostaOS v0.3\nMade by Cal\n"); break;
            case 't': { int sec = get_time_seconds(); char buf[12]; itoa(sec,buf); print_string("\nSeconds since midnight: "); print_string(buf); break; }
            case 'a': { volatile char* video_memory=(volatile char*)0xB8000; for(int i=1;i<80*25*2;i+=2){video_memory[i]^=0xFF;} break; }
            case 's': print_string("\nThis is a test string!\n"); break;
            case 'p': print_string("\n"); print_string(buffer+2); break;
            case 'b': print_string("\nCommand History:\n"); for(int i=0;i<hist_count;i++){print_string(history[i]); print_string("\n");} break;
            case 'w': { int x=buffer[2]-'0', y=buffer[4]-'0'; char c=buffer[6]; char color=0x1F; if(buffer[8]) color=buffer[8]; vga_write(c,color,x,y); break; }
            case 'd': dump_memory((uint8_t*)0xB8000, 80*25*2); break;
            case 'm': { uint8_t* addr=(uint8_t*)hex_to_int(buffer+2); char buf[5]; itoa(mem_read(addr),buf); print_string("\nMemory: "); print_string(buf); break; }
            case 'o': { uint8_t* addr=(uint8_t*)hex_to_int(buffer+2); uint8_t val=(uint8_t)hex_to_int(buffer+10); mem_write(addr,val); print_string("\nDone\n"); break; }
            case 'u': for(int i=2;buffer[i];i++){if(buffer[i]>='a'&&buffer[i]<='z')buffer[i]-=32;} print_string("\n"); print_string(buffer+2); break;
            case 'l': for(int i=2;buffer[i];i++){if(buffer[i]>='A'&&buffer[i]<='Z')buffer[i]+=32;} print_string("\n"); print_string(buffer+2); break;
            case 'f': fill_screen(buffer[2],0x07); break;
            case 'x': xor_screen(); break;
            case 'v': print_string("\nMini OS v0.3 detailed version\n"); break;
            case 'g': print_string("\nHello! Welcome to Mini OS!\n"); break;
            case 'n': hist_idx=(hist_idx+1)%hist_count; print_string("\n"); print_string(history[hist_idx]); break;
            case 'y': asm volatile("nop"); break;
            case 'z': zero_screen(); break;
            default: print_string("\nUnknown command\n");
        }
    }
}
// Variáveis globais
fs_superblock_t superblock;
uint8_t fs_initialized = 0;

void ata_wait_busy() {
    while (inb(0x1F7) & 0x80);
}

void ata_wait_drq() {
    while (!(inb(0x1F7) & 0x08));
}

void ata_read_sector(uint32_t lba, uint8_t* buffer) {
    ata_wait_busy();
    
    outb(0x1F6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(0x1F2, 1);
    outb(0x1F3, lba & 0xFF);
    outb(0x1F4, (lba >> 8) & 0xFF);
    outb(0x1F5, (lba >> 16) & 0xFF);
    outb(0x1F7, 0x20);
    
    ata_wait_busy();
    ata_wait_drq();
    
    for (int i = 0; i < 256; i++) {
        uint16_t data = inw(0x1F0);
        buffer[i * 2] = data & 0xFF;
        buffer[i * 2 + 1] = (data >> 8) & 0xFF;
    }
}

void ata_write_sector(uint32_t lba, uint8_t* buffer) {
    ata_wait_busy();
    
    outb(0x1F6, 0xE0 | ((lba >> 24) & 0x0F));
    outb(0x1F2, 1);
    outb(0x1F3, lba & 0xFF);
    outb(0x1F4, (lba >> 8) & 0xFF);
    outb(0x1F5, (lba >> 16) & 0xFF);
    outb(0x1F7, 0x30);
    
    ata_wait_busy();
    ata_wait_drq();
    
    for (int i = 0; i < 256; i++) {
        uint16_t data = (buffer[i * 2 + 1] << 8) | buffer[i * 2];
        outw(0x1F0, data);
    }
    
    outb(0x1F7, 0xE7);
    ata_wait_busy();
}

// Função print_int usando sua itoa existente
void print_int(uint32_t num) {
    char buffer[16];
    itoa(num, buffer);
    print_string(buffer);
}

// Função atoi

int fs_init() {
    ata_read_sector(FS_START_SECTOR, (uint8_t*)&superblock);
    
    if (superblock.magic != FS_MAGIC) {
        superblock.magic = FS_MAGIC;
        superblock.file_count = 0;
        
        for (int i = 0; i < FS_MAX_FILES; i++) {
            superblock.files[i].flags = 0;
            superblock.files[i].filename[0] = '\0';
        }
        
        ata_write_sector(FS_START_SECTOR, (uint8_t*)&superblock);
        print_string("FS: Formatted new filesystem at sector ");
        print_int(FS_START_SECTOR);
        print_string("\n");
    } else {
        print_string("FS: Found existing filesystem at sector ");
        print_int(FS_START_SECTOR);
        print_string("\n");
    }
    
    fs_initialized = 1;
    return 0;
}

int fs_format() {
    superblock.magic = FS_MAGIC;
    superblock.file_count = 0;
    
    for (int i = 0; i < FS_MAX_FILES; i++) {
        superblock.files[i].flags = 0;
        superblock.files[i].filename[0] = '\0';
    }
    
    ata_write_sector(FS_START_SECTOR, (uint8_t*)&superblock);
    print_string("FS: Filesystem formatted at sector ");
    print_int(FS_START_SECTOR);
    print_string("\n");
    return 0;
}

file_entry_t* fs_find_file(const char* filename) {
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (superblock.files[i].flags == 1 && 
            strcmp(superblock.files[i].filename, filename) == 0) {
            return &superblock.files[i];
        }
    }
    return NULL;
}

int fs_create_file(const char* filename, uint32_t size_sectors) {
    if (!fs_initialized) fs_init();
    
    if (fs_find_file(filename) != NULL) {
        print_string("FS: File already exists\n");
        return -1;
    }
    
    int free_slot = -1;
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (superblock.files[i].flags == 0) {
            free_slot = i;
            break;
        }
    }
    
    if (free_slot == -1) {
        print_string("FS: No free file slots\n");
        return -1;
    }
    
    // Calcular setor de início (após o superbloco)
    uint32_t file_start_sector = FS_START_SECTOR + 1 + (free_slot * 2);
    
    // Copiar nome do arquivo
    int i;
    for (i = 0; i < FS_FILENAME_LEN - 1 && filename[i] != '\0'; i++) {
        superblock.files[free_slot].filename[i] = filename[i];
    }
    superblock.files[free_slot].filename[i] = '\0';
    
    superblock.files[free_slot].start_sector = file_start_sector;
    superblock.files[free_slot].size_bytes = size_sectors * FS_SECTOR_SIZE;
    superblock.files[free_slot].flags = 1;
    superblock.file_count++;
    
    ata_write_sector(FS_START_SECTOR, (uint8_t*)&superblock);
    
    print_string("FS: Created file '");
    print_string(filename);
    print_string("' at sector ");
    print_int(file_start_sector);
    print_string("\n");
    
    return 0;
}

int fs_delete_file(const char* filename) {
    file_entry_t* file = fs_find_file(filename);
    if (!file) {
        print_string("FS: File not found\n");
        return -1;
    }
    
    file->flags = 0;
    file->filename[0] = '\0';
    superblock.file_count--;
    
    ata_write_sector(FS_START_SECTOR, (uint8_t*)&superblock);
    
    print_string("FS: Deleted file: ");
    print_string(filename);
    print_string("\n");
    return 0;
}

int fs_read_file(const char* filename, uint8_t* buffer, uint32_t offset, uint32_t length) {
    file_entry_t* file = fs_find_file(filename);
    if (!file) {
        print_string("FS: File not found\n");
        return -1;
    }
    
    if (offset >= file->size_bytes) {
        return 0;
    }
    
    if (offset + length > file->size_bytes) {
        length = file->size_bytes - offset;
    }
    
    uint32_t start_sector = file->start_sector + (offset / FS_SECTOR_SIZE);
    uint32_t sector_offset = offset % FS_SECTOR_SIZE;
    uint32_t bytes_read = 0;
    uint8_t sector_buffer[FS_SECTOR_SIZE];
    
    while (bytes_read < length) {
        ata_read_sector(start_sector, sector_buffer);
        
        uint32_t bytes_to_copy = FS_SECTOR_SIZE - sector_offset;
        if (bytes_to_copy > (length - bytes_read)) {
            bytes_to_copy = length - bytes_read;
        }
        
        memcpy(buffer + bytes_read, sector_buffer + sector_offset, bytes_to_copy);
        bytes_read += bytes_to_copy;
        start_sector++;
        sector_offset = 0;
    }
    
    return bytes_read;
}

int fs_write_file(const char* filename, uint8_t* buffer, uint32_t offset, uint32_t length) {
    file_entry_t* file = fs_find_file(filename);
    if (!file) {
        print_string("FS: File not found\n");
        return -1;
    }
    
    if (offset + length > file->size_bytes) {
        print_string("FS: Write exceeds file size\n");
        return -1;
    }
    
    uint32_t start_sector = file->start_sector + (offset / FS_SECTOR_SIZE);
    uint32_t sector_offset = offset % FS_SECTOR_SIZE;
    uint32_t bytes_written = 0;
    uint8_t sector_buffer[FS_SECTOR_SIZE];
    
    while (bytes_written < length) {
        if (sector_offset > 0 || (length - bytes_written) < FS_SECTOR_SIZE) {
            ata_read_sector(start_sector, sector_buffer);
        }
        
        uint32_t bytes_to_copy = FS_SECTOR_SIZE - sector_offset;
        if (bytes_to_copy > (length - bytes_written)) {
            bytes_to_copy = length - bytes_written;
        }
        
        memcpy(sector_buffer + sector_offset, buffer + bytes_written, bytes_to_copy);
        ata_write_sector(start_sector, sector_buffer);
        
        bytes_written += bytes_to_copy;
        start_sector++;
        sector_offset = 0;
    }
    
    return bytes_written;
}

void fs_chmod(const char* filename, uint8_t mode) {
    file_entry_t* f = fs_find_file(filename);
    if (!f) {
        print_string("chmod: no such file\n");
        return;
    }

    // bit 0x01 = usado → nunca remove
    // mode contém rwx nos bits baixos
    f->flags = (1 | (mode & 0x0E));

    ata_write_sector(FS_START_SECTOR, (uint8_t*)&superblock);
    print_string("chmod: ok\n");
}



void fs_list_files() {
    print_string("Files (FS starts at sector ");
    print_int(FS_START_SECTOR);
    print_string("):\n");
    
    int found = 0;
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (superblock.files[i].flags == 1) {
            print_string("  ");
            print_string(superblock.files[i].filename);
            print_string(" (");
            char size_str[16];
            itoa(superblock.files[i].size_bytes, size_str);
            print_string(size_str);
            print_string(" bytes, sector ");
            print_int(superblock.files[i].start_sector);
            print_string(")\n");
            found = 1;
        }
    }
    if (!found) {
        print_string("  No files found\n");
    }
}
#define FSH_MAX_CMD_LEN 128
#define FSH_MAX_ARGS 8
#define FSH_MAX_HISTORY 10

char fsh_history[FSH_MAX_HISTORY][FSH_MAX_CMD_LEN];
int fsh_hist_count = 0;
int fsh_hist_index = 0;

void fsh_clear_screen(void) {
    volatile char* video_memory = (volatile char*)0xB8000;
    for (int i = 0; i < 80 * 25 * 2; i += 2) {
        video_memory[i] = ' ';
        video_memory[i + 1] = 0x07;
    }
}

void fsh_add_history(const char* cmd) {
    if (fsh_hist_count < FSH_MAX_HISTORY) {
        strncpy(fsh_history[fsh_hist_count], cmd, FSH_MAX_CMD_LEN - 1);
        fsh_hist_count++;
    } else {
        // Rotacionar histórico
        for (int i = 1; i < FSH_MAX_HISTORY; i++) {
            strcpy(fsh_history[i-1], fsh_history[i]);
        }
        strncpy(fsh_history[FSH_MAX_HISTORY-1], cmd, FSH_MAX_CMD_LEN - 1);
    }
    fsh_hist_index = fsh_hist_count;
}

void fsh_show_banner(void) {
    print_string("=========================================\n");
    print_string("    Filesystem Shell (fsh) v1.0\n");
    print_string("=========================================\n");
}

void fsh_show_help(void) {
    print_string("\nFSH Commands:\n");
    print_string("  ls, list           - List files\n");
    print_string("  create <n> <s>     - Create file (s=sectors)\n");
    print_string("  del, rm <n>        - Delete file\n");
    print_string("  write <n> <t>      - Write text to file\n");
    print_string("  read <n>           - Read file content\n");
    print_string("  append <n> <t>     - Append text to file\n");
    print_string("  info <n>           - File information\n");
    print_string("  rename <o> <n>     - Rename file\n");
    print_string("  copy <s> <d>       - Copy file\n");
    print_string("  format             - Format filesystem\n");
    print_string("  status             - FS status\n");
    print_string("  df                 - Disk usage\n");
    print_string("  test               - Run tests\n");
    print_string("  hexdump <n>        - Hex view\n");
    print_string("  sectors <n>        - Show sectors\n");
    print_string("  clear, cls         - Clear screen\n");
    print_string("  history            - Command history\n");
    print_string("  b <num>             - Run from history\n");
    print_string("  exit, quit         - Exit FSH\n");
    print_string("  help, ?            - This help\n");
}
void fsh_show_status(void) {
    print_string("\n=== FILESYSTEM STATUS ===\n");
    print_string("Magic: 0x");
    char hex[5];
    itoa(superblock.magic >> 8, hex); print_string(hex);
    itoa(superblock.magic & 0xFF, hex); print_string(hex);
    print_string("\nTotal files: ");
    itoa(superblock.file_count, hex);
    print_string(hex);
    print_string("\nMax files: ");
    itoa(FS_MAX_FILES, hex);
    print_string(hex);
    print_string("\nSector size: ");
    itoa(FS_SECTOR_SIZE, hex);
    print_string(hex);
    print_string(" bytes\n");
}

void fsh_show_disk_usage(void) {
    print_string("\n=== DISK USAGE ===\n");
    int used_files = 0;
    uint32_t total_used_bytes = 0;
    
    for (int i = 0; i < FS_MAX_FILES; i++) {
        if (superblock.files[i].flags == 1) {
            used_files++;
            total_used_bytes += superblock.files[i].size_bytes;
        }
    }
    
    char buf[16];
    print_string("Files: ");
    itoa(used_files, buf); print_string(buf);
    print_string("/");
    itoa(FS_MAX_FILES, buf); print_string(buf);
    print_string("\nUsed space: ");
    itoa(total_used_bytes, buf); print_string(buf);
    print_string(" bytes\n");
    
    // Calcular uso aproximado em setores
    uint32_t total_sectors = total_used_bytes / FS_SECTOR_SIZE;
    if (total_used_bytes % FS_SECTOR_SIZE) total_sectors++;
    
    print_string("Used sectors: ~");
    itoa(total_sectors, buf); print_string(buf);
    print_string("\n");
}

void fsh_rename_file(const char* old_name, const char* new_name) {
    file_entry_t* file = fs_find_file(old_name);
    if (!file) {
        print_string("File not found: ");
        print_string(old_name);
        print_string("\n");
        return;
    }
    
    if (fs_find_file(new_name)) {
        print_string("File already exists: ");
        print_string(new_name);
        print_string("\n");
        return;
    }
    
    strncpy(file->filename, new_name, FS_FILENAME_LEN - 1);
    ata_write_sector(0, (uint8_t*)&superblock);
    
    print_string("Renamed '");
    print_string(old_name);
    print_string("' to '");
    print_string(new_name);
    print_string("'\n");
}

void fsh_copy_file(const char* src_name, const char* dest_name) {
    file_entry_t* src_file = fs_find_file(src_name);
    if (!src_file) {
        print_string("Source file not found: ");
        print_string(src_name);
        print_string("\n");
        return;
    }
    
    if (fs_find_file(dest_name)) {
        print_string("Destination file already exists: ");
        print_string(dest_name);
        print_string("\n");
        return;
    }
    
    // Criar novo arquivo com mesmo tamanho
    uint32_t sectors = (src_file->size_bytes + FS_SECTOR_SIZE - 1) / FS_SECTOR_SIZE;
    if (fs_create_file(dest_name, sectors) == 0) {
        // Copiar dados
        uint8_t* buffer = (uint8_t*)0x10000; // Usar memória temporária
        int bytes_read = fs_read_file(src_name, buffer, 0, src_file->size_bytes);
        if (bytes_read > 0) {
            fs_write_file(dest_name, buffer, 0, bytes_read);
            print_string("Copied ");
            char buf[16];
            itoa(bytes_read, buf);
            print_string(buf);
            print_string(" bytes from '");
            print_string(src_name);
            print_string("' to '");
            print_string(dest_name);
            print_string("'\n");
        }
    }
}

void fsh_append_file(const char* filename, const char* text) {
    file_entry_t* file = fs_find_file(filename);
    if (!file) {
        print_string("File not found: ");
        print_string(filename);
        print_string("\n");
        return;
    }
    
    fs_write_file(filename, (uint8_t*)text, file->size_bytes, strlen(text));
    
    print_string("Appended ");
    char buf[16];
    itoa(strlen(text), buf);
    print_string(buf);
    print_string(" bytes to '");
    print_string(filename);
    print_string("'\n");
}

void fsh_hexdump(const char* filename) {
    file_entry_t* file = fs_find_file(filename);
    if (!file) {
        print_string("File not found: ");
        print_string(filename);
        print_string("\n");
        return;
    }
    
    uint8_t buffer[16];
    uint32_t offset = 0;
    
    print_string("\nHex dump of '");
    print_string(filename);
    print_string("':\n");
    
    while (offset < file->size_bytes) {
        // Mostrar offset
        char hex[9];
        itoa(offset >> 28, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        itoa((offset >> 24) & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        itoa((offset >> 20) & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        itoa((offset >> 16) & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        itoa((offset >> 12) & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        itoa((offset >> 8) & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        itoa((offset >> 4) & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        itoa(offset & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
        print_string(": ");
        
        // Ler 16 bytes
        uint32_t to_read = 16;
        if (offset + to_read > file->size_bytes) {
            to_read = file->size_bytes - offset;
        }
        
        fs_read_file(filename, buffer, offset, to_read);
        
        // Mostrar hex
        for (int i = 0; i < 16; i++) {
            if (i < to_read) {
                itoa(buffer[i] >> 4, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
                itoa(buffer[i] & 0xF, hex); print_char(hex[0] < 10 ? '0' + hex[0] : 'A' + hex[0] - 10);
            } else {
                print_string("  ");
            }
            print_char(' ');
            if (i == 7) print_char(' ');
        }
        
        print_string(" ");
        
        // Mostrar ASCII
        for (int i = 0; i < to_read; i++) {
            print_char(buffer[i] >= 32 && buffer[i] < 127 ? buffer[i] : '.');
        }
        
        print_string("\n");
        offset += 16;
    }
}

void fsh_show_sectors(const char* filename) {
    file_entry_t* file = fs_find_file(filename);
    if (!file) {
        print_string("File not found: ");
        print_string(filename);
        print_string("\n");
        return;
    }
    
    print_string("\nFile: ");
    print_string(filename);
    print_string("\nStart sector: ");
    char buf[16];
    itoa(file->start_sector, buf);
    print_string(buf);
    print_string("\nSize: ");
    itoa(file->size_bytes, buf);
    print_string(buf);
    print_string(" bytes\n");
    print_string("Sectors: ");
    itoa(file->start_sector, buf);
    print_string(buf);
    print_string(" to ");
    itoa(file->start_sector + (file->size_bytes + FS_SECTOR_SIZE - 1) / FS_SECTOR_SIZE - 1, buf);
    print_string(buf);
    print_string("\n");
}

void fsh_run_tests(void) {
    print_string("\n=== FILESYSTEM TESTS ===\n");
    
    // Test 1: Create file
    print_string("1. Creating test file... ");
    if (fs_create_file("TEST_FILE", 2) == 0) {
        print_string("OK\n");
    } else {
        print_string("FAILED\n");
        return;
    }
    
    // Test 2: Write data
    print_string("2. Writing test data... ");
    uint8_t test_data[] = "Hello, this is a test file!";
    if (fs_write_file("TEST_FILE", test_data, 0, sizeof(test_data)) > 0) {
        print_string("OK\n");
    } else {
        print_string("FAILED\n");
        return;
    }
    
    // Test 3: Read data
    print_string("3. Reading test data... ");
    uint8_t read_buf[128];
    int bytes = fs_read_file("TEST_FILE", read_buf, 0, sizeof(read_buf));
    if (bytes > 0 && strcmp((char*)read_buf, (char*)test_data) == 0) {
        print_string("OK\n");
    } else {
        print_string("FAILED\n");
        return;
    }
    
    // Test 4: List files
    print_string("4. Listing files... ");
    fs_list_files();
    print_string("OK\n");
    
    // Test 5: Cleanup
    print_string("5. Cleaning up... ");
    fs_delete_file("TEST_FILE");
    print_string("OK\n");
    
    print_string("All tests passed! Filesystem is working correctly.\n");
}

void fsh(void) {
    char buffer[FSH_MAX_CMD_LEN];
    char* args[FSH_MAX_ARGS];
    
    fsh_clear_screen();
    fsh_show_banner();
    fsh_show_help();
    
    fs_init();
    
    while (1) {
        print_string("\nfsh> ");
        
        // Ler comando
        input_string(buffer, FSH_MAX_CMD_LEN);
        fsh_add_history(buffer);
        
        // Parsear argumentos
        int arg_count = 0;
        char* token = buffer;
        for (int i = 0; i < FSH_MAX_ARGS; i++) {
            args[i] = NULL;
        }
        
        while (*token && arg_count < FSH_MAX_ARGS) {
            while (*token == ' ') token++;
            if (!*token) break;
            
            args[arg_count++] = token;
            
            while (*token && *token != ' ') token++;
            if (*token) *token++ = 0;
        }
        
        if (arg_count == 0) continue;
        
        // EXECUTAR COMANDOS
        if (strcmp(args[0], "help") == 0 || strcmp(args[0], "?") == 0) {
            fsh_show_help();
        }
        else if (strcmp(args[0], "ls") == 0 || strcmp(args[0], "list") == 0) {
            fs_list_files();
        }
        else if (strcmp(args[0], "create") == 0) {
            if (arg_count >= 3) {
                uint32_t size = atoi(args[2]);
                if (size > 0) {
                    fs_create_file(args[1], size);
                } else {
                    print_string("Error: Size must be > 0\n");
                }
            } else {
                print_string("Usage: create <filename> <size_sectors>\n");
            }
        }
        else if (strcmp(args[0], "del") == 0 || strcmp(args[0], "rm") == 0) {
            if (arg_count >= 2) {
                fs_delete_file(args[1]);
            } else {
                print_string("Usage: del <filename>\n");
            }
        }
        else if (strcmp(args[0], "write") == 0) {
            if (arg_count >= 3) {
                char full_text[256] = {0};
                strcpy(full_text, args[2]);
                for (int i = 3; i < arg_count; i++) {
                    strcat(full_text, " ");
                    strcat(full_text, args[i]);
                }
                
                int bytes = fs_write_file(args[1], (uint8_t*)full_text, 0, strlen(full_text));
                if (bytes > 0) {
                    print_string("OK - wrote ");
                    char buf[16];
                    itoa(bytes, buf);
                    print_string(buf);
                    print_string(" bytes\n");
                }
            } else {
                print_string("Usage: write <filename> <text>\n");
            }
        }
        else if (strcmp(args[0], "read") == 0) {
            if (arg_count >= 2) {
                file_entry_t* file = fs_find_file(args[1]);
                if (file) {
                    uint8_t read_buf[1024];
                    uint32_t to_read = file->size_bytes < 1024 ? file->size_bytes : 1024;
                    int bytes = fs_read_file(args[1], read_buf, 0, to_read);
                    
                    if (bytes > 0) {
                        print_string("Content: \"");
                        for (int i = 0; i < bytes && read_buf[i] != 0; i++) {
                            print_char(read_buf[i]);
                        }
                        print_string("\"\n");
                    } else {
                        print_string("File is empty or error reading\n");
                    }
                } else {
                    print_string("File not found\n");
                }
            } else {
                print_string("Usage: read <filename>\n");
            }
        }
        else if (strcmp(args[0], "append") == 0) {
            if (arg_count >= 3) {
                char full_text[256] = {0};
                strcpy(full_text, args[2]);
                for (int i = 3; i < arg_count; i++) {
                    strcat(full_text, " ");
                    strcat(full_text, args[i]);
                }
                fsh_append_file(args[1], full_text);
            } else {
                print_string("Usage: append <filename> <text>\n");
            }
        }
        else if (strcmp(args[0], "info") == 0) {
            if (arg_count >= 2) {
                file_entry_t* file = fs_find_file(args[1]);
                if (file) {
                    print_string("Name: ");
                    print_string(file->filename);
                    print_string("\nSize: ");
                    char buf[16];
                    itoa(file->size_bytes, buf);
                    print_string(buf);
                    print_string(" bytes\nStart sector: ");
                    itoa(file->start_sector, buf);
                    print_string(buf);
                    print_string("\n");
                } else {
                    print_string("File not found\n");
                }
            } else {
                print_string("Usage: info <filename>\n");
            }
        }
        else if (strcmp(args[0], "rename") == 0) {
            if (arg_count >= 3) {
                fsh_rename_file(args[1], args[2]);
            } else {
                print_string("Usage: rename <oldname> <newname>\n");
            }
        }
        else if (strcmp(args[0], "copy") == 0) {
            if (arg_count >= 3) {
                fsh_copy_file(args[1], args[2]);
            } else {
                print_string("Usage: copy <src> <dest>\n");
            }
        }
        else if (strcmp(args[0], "format") == 0) {
            print_string("WARNING: This will erase ALL files! Continue? (y/N): ");
            char confirm[10];
            input_string(confirm, 10);
            if (confirm[0] == 'y' || confirm[0] == 'Y') {
                fs_format();
                print_string("Filesystem formatted\n");
            } else {
                print_string("Format cancelled\n");
            }
        }
        else if (strcmp(args[0], "status") == 0) {
            fsh_show_status();
        }
        else if (strcmp(args[0], "df") == 0) {
            fsh_show_disk_usage();
        }
        else if (strcmp(args[0], "test") == 0) {
            fsh_run_tests();
        }
        else if (strcmp(args[0], "hexdump") == 0) {
            if (arg_count >= 2) {
                fsh_hexdump(args[1]);
            } else {
                print_string("Usage: hexdump <filename>\n");
            }
        }
        else if (strcmp(args[0], "sectors") == 0) {
            if (arg_count >= 2) {
                fsh_show_sectors(args[1]);
            } else {
                print_string("Usage: sectors <filename>\n");
            }
        }
        else if (strcmp(args[0], "history") == 0) {
            print_string("\nCommand history:\n");
            for (int i = 0; i < fsh_hist_count; i++) {
                print_string("  ");
                char num[4];
                itoa(i, num);
                print_string(num);
                print_string(": ");
                print_string(fsh_history[i]);
                print_string("\n");
            }
        }
        else if (args[0][0] == 'b') {
            // Executar comando do histórico
            int hist_num = atoi(args[0] + 1);
            if (hist_num >= 0 && hist_num < fsh_hist_count) {
                print_string("Executing: ");
                print_string(fsh_history[hist_num]);
                print_string("\n");
                // Aqui você poderia re-executar o comando
            } else {
                print_string("History number out of range\n");
            }
        }
        else if (strcmp(args[0], "clear") == 0 || strcmp(args[0], "cls") == 0) {
            fsh_clear_screen();
            fsh_show_banner();
        }
        else if (strcmp(args[0], "exit") == 0 || strcmp(args[0], "quit") == 0) {
            print_string("Goodbye! Returning to main shell...\n");
            break;
        }
        else {
            print_string("Unknown command: '");
            print_string(args[0]);
            print_string("'\nType 'help' for available commands\n");
        }
    }
}

//================shell======================
#define NSH_MAX_CMD 128
#define NSH_MAX_ARGS 8
#define NSH_MAX_HISTORY 32

static char nsh_history[NSH_MAX_HISTORY][NSH_MAX_CMD];
static int nsh_hist_count = 0;
static int nsh_hist_idx = 0;

void nsh_add_history(const char* cmd) {
    if (nsh_hist_count < NSH_MAX_HISTORY) {
        strncpy(nsh_history[nsh_hist_count], cmd, NSH_MAX_CMD - 1);
        nsh_hist_count++;
    } else {
        for (int i = 1; i < NSH_MAX_HISTORY; i++)
            strcpy(nsh_history[i-1], nsh_history[i]);
        strncpy(nsh_history[NSH_MAX_HISTORY-1], cmd, NSH_MAX_CMD - 1);
    }
    nsh_hist_idx = nsh_hist_count;
}

void nsh_exec(char* cmd);

// ======================================================
//  PARSER
// ======================================================
int nsh_parse(char* buffer, char* args[], int max_args) {
    int count = 0;
    char* t = buffer;

    for (int i = 0; i < max_args; i++) args[i] = NULL;

    while (*t && count < max_args) {
        while (*t == ' ') t++;
        if (!*t) break;

        args[count++] = t;
        while (*t && *t != ' ') t++;
        if (*t) *t++ = 0;
    }
    return count;
}

// ======================================================
//     N S H    C O M A N D S
// ======================================================
void pause_screen() {
    kernelf("\n--press one key to run...--");
    input(); // espera tecla
    print_string("\n");
}

void nsh_help(void) {
    print_string(" h / help     - help\n");
    print_string(" c / clear    - clear screen\n");
    print_string(" r / reboot   - reboot\n");
    print_string(" exit / quit  - exit shell\n");
    print_string(" memread      - read memory\n");
    print_string(" memwrite     - write memory\n");
    print_string(" time         - system time\n");
    print_string(" invert       - invert screen\n");
    pause_screen();
    print_string(" fill <c>     - fill screen\n");
    print_string(" xor          - xor screen\n");
    print_string(" ls, list\n create <n> <s> -- del <n>\n write <n> <t>\n read <n>\n");
    print_string(" append <n> <t>\n rename <o> <n>\n copy <s> <d>\n");
    print_string(" info <n>\n sectors <n>\n");
    print_string(" format\n status\n df\n");
    print_string(" history\n b<num>  - run history entry\n");
}

// ======================================================
// SHELL EXEC (interpreta comandos)
// ======================================================
void nsh_exec(char* cmd_raw) {
    char cmd[NSH_MAX_CMD];
    char* args[NSH_MAX_ARGS];
    strncpy(cmd, cmd_raw, NSH_MAX_CMD-1);

    int argc = nsh_parse(cmd, args, NSH_MAX_ARGS);
    if (argc == 0) return;

    // ----------------------
    //   SYSTEM COMMANDS
    // ----------------------
    if (strcmp(args[0], "h") == 0 || strcmp(args[0], "help") == 0) {
        nsh_help();
    }
    else if (strcmp(args[0], "c") == 0 || strcmp(args[0], "clear") == 0) {
        clear_screen();
    }
    else if (strcmp(args[0], "r") == 0 || strcmp(args[0], "reboot") == 0) {
        asm volatile("int $0x19");
    }
    else if (strcmp(args[0], "exit") == 0 || strcmp(args[0], "quit") == 0) {
        asm volatile("hlt");
    }
    else if (strcmp(args[0], "time") == 0) {
        char b[12];
        itoa(get_time_seconds(), b);
        print_string("Seconds since midnight: ");
        print_string(b); print_string("\n");
    }
    else if (strcmp(args[0], "invert") == 0) {
        invert_colors();
    }
    else if (strcmp(args[0], "xor") == 0) {
        xor_screen();
    }
    else if (strcmp(args[0], "fill") == 0) {
        if (argc >= 2) fill_screen(args[1][0], 0x07);
        else print_string("Usage: fill <char>\n");
    }

    // ============================================================
    // FILESYSTEM COMMANDS
    // ============================================================
    else if (strcmp(args[0], "ls") == 0 || strcmp(args[0], "list") == 0) {
        fs_list_files();
    }
    else if (strcmp(args[0], "create") == 0 && argc >= 3) {
        fs_create_file(args[1], atoi(args[2]));
    }
    else if ((strcmp(args[0], "del") == 0 || strcmp(args[0], "rm") == 0) && argc >= 2) {
        fs_delete_file(args[1]);
    }
    else if (strcmp(args[0], "write") == 0 && argc >= 3) {
        char txt[256] = {0};
        strcpy(txt, args[2]);
        for (int i = 3; i < argc; i++) { strcat(txt, " "); strcat(txt, args[i]); }
        fs_write_file(args[1], (uint8_t*)txt, 0, strlen(txt));
    }
    else if (strcmp(args[0], "read") == 0 && argc >= 2) {
        uint8_t buf[1024];
        int r = fs_read_file(args[1], buf, 0, 1024);
        print_string("Content: ");
        for (int i = 0; i < r; i++) print_char(buf[i]);
        print_string("\n");
    }
    else if (strcmp(args[0], "append") == 0 && argc >= 3) {
        char txt[256] = {0};
        strcpy(txt, args[2]);
        for (int i=3;i<argc;i++){ strcat(txt," "); strcat(txt,args[i]); }
        fsh_append_file(args[1], txt);
    }
    else if (strcmp(args[0], "rename") == 0 && argc >= 3) {
        fsh_rename_file(args[1], args[2]);
    }
    else if (strcmp(args[0], "copy") == 0 && argc >= 3) {
        fsh_copy_file(args[1], args[2]);
    }
    else if (strcmp(args[0], "format") == 0) {
        print_string("Format? (y/N): ");
        char c[8];
        input_string(c, 8);
        if (c[0]=='y'||c[0]=='Y') fs_format();
    }
    else if (strcmp(args[0], "status") == 0) {
        fsh_show_status();
    }
    else if (strcmp(args[0], "df") == 0) {
        fsh_show_disk_usage();
    }

    // ============================================================
    // HISTORY
    // ============================================================
    else if (strcmp(args[0], "history") == 0) {
        for (int i=0; i<nsh_hist_count; i++) {
            char n[4]; itoa(i,n);
            print_string(n); print_string(": ");
            print_string(nsh_history[i]); print_string("\n");
        }
    }

    else if (args[0][0] == 'b') {
        int n = atoi(args[0] + 1);
        if (n >= 0 && n < nsh_hist_count) {
            print_string("Running: ");
            print_string(nsh_history[n]); print_string("\n");
            nsh_exec(nsh_history[n]);
        } else print_string("Invalid history entry\n");
    }
    else {
        print_string("Unknown command\n");
    }
}

// ======================================================
// MAIN LOOP
// ======================================================
void nsh(void) {
    char buffer[NSH_MAX_CMD];

    print_string("=== NSH — Unified Shell ===\n");

    while (1) {
        print_string("\n> ");
        input_string(buffer, NSH_MAX_CMD);

        nsh_add_history(buffer);
        nsh_exec(buffer);
    }
}

void kmain(void) {
    // Limpar tela
    volatile char* video_memory = (volatile char*)0xB8000;
    for (int i = 0; i < 80 * 25 * 2; i += 2) {
        video_memory[i] = ' ';
        video_memory[i + 1] = 0x07;
    }
   
    

    run();
    
    
}      
