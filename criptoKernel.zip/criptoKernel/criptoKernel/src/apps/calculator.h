#ifndef AAA_H
#define AAA_H
#include <libkernel/io.h>

#define FP_SCALE 10000
#define PI 31416
#define TAU 62832

int read_int() {
    char buffer[16];
    int idx = 0;
    char c;
    
    print_string("> ");
    
    while(1) {
        c = input();
        if(c == '\n' || c == '\r') { buffer[idx] = 0; break; }
        else if(c == '\b') { 
            if(idx > 0){
                idx--;
                print_char('\b');
                print_char(' ');
                print_char('\b');
            }
        }
        else if(c >= '0' && c <= '9' && idx < 15){
            buffer[idx++] = c;
            print_char(c);
        }
    }
    
    int val = 0;
    for(int i = 0; buffer[i]; i++) val = val*10 + (buffer[i]-'0');
    return val;
}

void print_fp(int val) {
    if(val < 0){ print_char('-'); val = -val; }
    int int_part = val / FP_SCALE;
    int frac_part = val % FP_SCALE;
    char buf[16];
    int idx = 0;
    
    if(int_part == 0) buf[idx++] = '0';
    else {
        int tmp = int_part, j = 0, tbuf[10];
        while(tmp){ tbuf[j++] = tmp % 10; tmp /= 10; }
        while(j > 0){ buf[idx++] = tbuf[--j] + '0'; }
    }
    
    buf[idx++] = '.';
    
    int f = frac_part;
    for(int i = 0; i < 4; i++){
        buf[idx++] = '0' + (f / 1000);
        f = (f % 1000) * 10;
    }
    buf[idx] = 0;
    
    print_string(buf);
}

void mini_calc_pi_tau() {
    kernelf("=========== please use min 6 digits =========");
    print_string("\n\n===calculator ===\n");

    while(1){
        print_string("\nChoose operation:\n");
        print_string(" 1 - Add\n 2 - Subtract\n 3 - Multiply\n 4 - Divide\n");
        print_string(" 5 - PI\n 6 - TAU\n e - Exit\nChoice: ");
        
        char op = input();
        print_char(op);
        print_string("\n");
        
        if(op == 'e') break;

        int a = 0, b = 0;

        if(op < '5'){ 
            print_string("\nEnter first number:\n ");
            a = read_int() * FP_SCALE;
            print_string("\nEnter second number: \n");
            b = read_int() * FP_SCALE;
        }
        else if(op == '5') a = PI;
        else if(op == '6') a = TAU;

        int result = 0;
        int error = 0;

        switch(op){
            case '1': result = a + b; break;
            case '2': result = a - b; break;
            case '3': result = (int)(((long long)a * (long long)b) / FP_SCALE); break;
            case '4': 
                if(b != 0) result = (int)(((long long)a * FP_SCALE) / b);
                else error = 1;
                break;
            case '5': result = a; break;
            case '6': result = a; break;
            default: print_string("\nInvalid option!\n"); continue;
        }

        if(error) print_string("Error: Division by zero!\n");
        else {
            print_string("\nResult: ");
            print_fp(result);
            print_string("\n");
        }
    }
    print_string("Exiting calculator.\n");
}

#endif

