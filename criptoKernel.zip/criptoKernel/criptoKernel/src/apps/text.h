#ifndef AA_H
#define AA_H
#include <libkernel/io.h>


#define MAX_LINES 25
#define MAX_COLS  80

char text_buffer[MAX_LINES][MAX_COLS];
int cur_x = 0;
int cur_y = 0;

void move_cursor(int x, int y) {
    unsigned short pos = y * 80 + x;
    outb(0x3D4, 0x0F);
    outb(0x3D5, (unsigned char)(pos & 0xFF));
    outb(0x3D4, 0x0E);
    outb(0x3D5, (unsigned char)((pos >> 8) & 0xFF));
}

void editor_putc(char c) {
    text_buffer[cur_y][cur_x] = c;
    print_char(c);

    cur_x++;
    if(cur_x >= MAX_COLS) {
        cur_x = 0;
        cur_y++;
        if(cur_y >= MAX_LINES) cur_y = MAX_LINES - 1;
    }

    move_cursor(cur_x, cur_y);
}

void editor_backspace() {
    if(cur_x == 0 && cur_y == 0) return;

    if(cur_x > 0) {
        cur_x--;
    } else {
        cur_y--;
        cur_x = MAX_COLS - 1;
    }

    text_buffer[cur_y][cur_x] = ' ';

    move_cursor(cur_x, cur_y);
    print_char(' ');
    move_cursor(cur_x, cur_y);
}

void editor_newline() {
    cur_y++;
    cur_x = 0;
    if(cur_y >= MAX_LINES) cur_y = MAX_LINES - 1;

    print_char('\n');
    move_cursor(cur_x, cur_y);
}

void editor_clear() {
    for(int i = 0; i < MAX_LINES; i++)
        for(int j = 0; j < MAX_COLS; j++)
            text_buffer[i][j] = ' ';
}

void editor_show() {
    print_string("\n\n--- FILE CONTENT BEGIN ---\n");
    for(int i = 0; i < MAX_LINES; i++) {
        for(int j = 0; j < MAX_COLS; j++) {
            char c = text_buffer[i][j];
            if(c == 0) c = ' ';
            print_char(c);
        }
        print_char('\n');
    }
    print_string("--- FILE CONTENT END ---\n");
}

void mini_editor() {
    editor_clear();
    cur_x = 0;
    cur_y = 0;

    print_string("Mini Editor Bare Metal\n");
    print_string("commands:\n");
    print_string(" 1 = save\n");
    print_string(" 2 = exit\n");
    print_string(" 3 = clear\n");
    print_string(" 4 = conteude\n");
    print_string("\nyou text:\n\n");

    move_cursor(cur_x, cur_y);

    while(1) {
        char c = input();

        if(c == '1') {
            editor_show();
            print_string("\n(running editor...)\n");
        }
        else if(c == '2') {
            return; // sair do editor
        }
        else if(c == '3') {
            editor_clear();
            print_string("\n[Tela limpa]\n");
            cur_x = 0;
            cur_y = 0;
            move_cursor(cur_x, cur_y);
        }
        else if(c == '4') {
            editor_show();
        }
        else if(c == '\b') {
            editor_backspace();
        }
        else if(c == '\n' || c == '\r') {
            editor_newline();
        }
        else if(c >= 32 && c <= 126) {
            editor_putc(c);
        }
    }
}
#endif
